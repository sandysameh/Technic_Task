import React from 'react'

 function add(){
    return(

<form id="MyTeam" onSubmit={this.addItem}>
        <input type="text" placeholder="Enter the member name"
        value={this.state.currentItem.text}
        onChange={this.handleInput}
        />
        <button name="submit"type="submit">ADD</button>
        <button name="cancel" type="submit">Cancel</button>
</form>



    )
}
export default add; 