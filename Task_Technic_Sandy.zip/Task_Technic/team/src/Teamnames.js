import React from 'react';
import './Teamnames.css'

function Teamnames(props){
  const items=props.items;
  const listuser = items.map(item =>
    {
        return <div className="user" key={item.key}>
            <p>
                <input type="text" 
                id={item.key}
                value={item.text}
                onChange={
                    (e)=>{
                        props.setUpdate(e.target.value,item.key)
                    } 
                 } />
                


            <span>
            <button  onClick={()=>props.deleteItem(item.key)}>Delete</button>
            </span>
            </p>
            
            </div>
    }
    )
  return(
  <div>{listuser}</div>

    )


}
export default Teamnames;